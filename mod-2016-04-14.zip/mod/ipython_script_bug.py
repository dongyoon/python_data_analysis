def f(x,y,z):
	if(z==0) :
		throws_an_exception()
	return (x+y)/z

a = 5
b = 6
c = 0

result = f(a,b,c)